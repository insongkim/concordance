concord_test <-
function(){
    print("Don't worry about warning messages produced by this function. What matters is the TRUE outcome")
    test_result = TRUE
    
    # Tests here.
    return(test_result)
}
